
import random
import prompt
import math


def welcome_user():
    print('Welcome to the Brain Games!')
    name = prompt.string('May I have your name? ')
    print(f'Hello,{name}!')
    return name


def arifm(operation, number1, number2):
    if operation == '+':
        result = number1 + number2
    elif operation == '-':
        result = number1 - number2
    else:
        result = number1 * number2
    return result


def pr(num):
    b = 0
    for i in range(2, 9):
        if (num % i) == 0:
            b += 1
    if (num > 9 and b > 0) or (num <= 9 and b > 1):
        return 'no'
    elif (num > 9 and b == 0) or (num < 9 and b == 1):
        return 'yes'


def question_and_answer(question, result, name, a):
    print(f"Question: {question}")
    if result == int:
        ans = prompt.integer('Your answer: ')
    elif result == str(result):
        ans = prompt.string('Your answer: ')
    else:
        ans = prompt.integer('Your answer: ')
    if ans == result:
        print('Correct!')
        if a == 0:
            print(f'Congratulations, {name}!')
            return False
        else:
            return True
    else:
        print(f"{ans} is wrong answer ;( Correct answer was '{result}'")
        print(f"Let's try again, {name}!")
        return False
