

import random
from brain_games.cli import question_and_answer


def progression(name):
    print('What number is missing in the progression?')
    a = 3
    while a > 0:
        number1 = random.randint(0,10)
        number2 = random.randint(80,100)
        st = random.randint(1,10)
        numbers = []
        for i in range(number1, number2, st):
            numbers.append(i)
        numbers.sort()
        nom = random.randint(0,9)
        n = numbers[nom]
        result = int(n)
        numbers[nom] = '..'
        question = " ".join(map(str, numbers[0:10]))
        a -=1
        command = question_and_answer(question, result, name, a)
        if command == True:
            continue
        else:
            break
