

import random
import prompt


def even(name):
    print('Answer "yes" if the number is even, otherwise answer "no".')
    a = 3
    while a > 0:
        num = random.randint(1, 100)
        print(f'Question:{num}')
        ans = prompt.string('Your answer: ')
        if (num % 2 == 0 and ans == 'yes') or (num % 2 > 0 and ans == 'no'):
            a -= 1
            print("Correct!")
            if a == 0:
                print(f'Congratulations, {name}!')
            else:
                continue
        else:
            break
