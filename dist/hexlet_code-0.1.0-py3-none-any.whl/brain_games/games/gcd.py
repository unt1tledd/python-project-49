

import prompt
import random
import math
from brain_games.cli import question_and_answer


def mygcd(name):
    print('Find the greatest common divisor of given numbers.')
    a = 3
    while a > 0:
        number1 = random.randint(1, 100)
        number2 = random.randint(1, 100)
        result = math.gcd(number1, number2)
        question = f"{number1} {number2}"
        a -= 1
        command = question_and_answer(question, result, name, a)
        if command == True:
            continue
        else:
            break