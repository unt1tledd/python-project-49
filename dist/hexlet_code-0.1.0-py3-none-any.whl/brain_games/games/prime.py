

import random
from brain_games.cli import pr
from brain_games.cli import question_and_answer


def prime(name):
    print('Answer "yes" if given number is prime. Otherwise answer "no".')
    a = 3
    while a > 0:
        question = random.randint(2, 100)
        result = pr(question)
        a -= 1
        command = question_and_answer(question, result, name, a)
        if command == True:
            continue
        else:
            break