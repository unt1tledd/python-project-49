

from brain_games.cli import welcome_user
from brain_games.games.gcd import mygcd


def main():
    name = welcome_user()
    mygcd(name)


if __name__ == '__main__':
    main()
